package com.bjpowernode.crm.settings.dao;

import com.bjpowernode.crm.settings.domain.DicType;
import com.bjpowernode.crm.settings.domain.DicValue;
import com.bjpowernode.crm.settings.domain.User;

import java.util.List;
import java.util.Map;

public interface DicTypeDao {

    List<DicType> getTypeList();
}
