package com.bjpowernode.crm.workbench.dao;

import com.bjpowernode.crm.workbench.domain.Contacts;

public interface ContactsDao {

    int save(Contacts con);
}
