package com.bjpowernode.crm.workbench.dao;

import com.bjpowernode.crm.workbench.domain.ContactsRemark;

public interface ContactsRemarkDao {

    int save(ContactsRemark contactsRemark);
}
