package com.bjpowernode.crm.workbench.service;

import java.util.List;

/**
 * Author 北京动力节点
 */
public interface CustomerService {
    List<String> getCustomerName(String name);
}
