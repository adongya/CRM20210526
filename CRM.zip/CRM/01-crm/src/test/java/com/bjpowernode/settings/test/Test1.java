package com.bjpowernode.settings.test;

import com.bjpowernode.crm.utils.DateTimeUtil;
import com.bjpowernode.crm.utils.MD5Util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Test1 {
    public static void main(String[] args) {
//        验证失效时间
//        失效时间
//        String expirTime = "2021-10-10 10:10:10";
//        //当前系统时间
//        String currentTime = DateTimeUtil.getSysTime();
//
//        int count = expirTime.compareTo(currentTime);
//
//        System.out.println(count);
//
//        String lockState = "0";
//        if ("0".equals(lockState)){
//            System.out.println("账号已锁定");
//        }
//
//        //浏览器段的ip地址
//        String ip = "192.168.1.1";
//        String allowIps = "192.168.1.1,192.168.34.66";
//        if (allowIps.contains(ip)){
//            System.out.println("有效的ip地址，允许访问系统");
//        }else {
//            System.out.println("无效的ip");
//        }
        String pwd = "Ymjbjpowernode123@";
        pwd = MD5Util.getMD5(pwd);
        System.out.println(pwd);



    }
}
